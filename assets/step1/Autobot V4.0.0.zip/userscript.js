function LoadintegralScript(AUTOBOTURL, timestamp){
    AUTOBOTURL += "&v=" + timestamp
    // install plugin cors-unblock: cors-unblock FIREFOX "https://addons.mozilla.org/fr/firefox/addon/cors-unblock/" | chrome "https://chromewebstore.google.com/detail/cors-unblock/lfhmikememgdcahcdlaciloancbhjino" and enable access-control-[allow/expose]-headers
    if (!window.jQuery) {
        var JQUERY_SCRIPT = document.createElement("script");
        JQUERY_SCRIPT.setAttribute("src", "https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js");
        JQUERY_SCRIPT.setAttribute("type", "text/javascript");
        document.getElementsByTagName("body")[0].appendChild(JQUERY_SCRIPT);
    }

    var AUTO_BOT = document.createElement("script");
    AUTO_BOT.setAttribute("src", AUTOBOTURL);
    AUTO_BOT.setAttribute("type", "text/javascript");
    AUTO_BOT.onload = function() {
        console.log("MAIN FILE LOADED");
    };
    document.getElementsByTagName("body")[0].appendChild(AUTO_BOT);
}

(function() {
    var defaultExternalproxy = {
        host: "",
        port: "",
        username: "",
        password: "",
        bypassList: ["icanhazip.com","*.js*","*.css*", "*.png*", "*.jpg*", "*.mp4*"],
    }
    window.proxyCreds = defaultExternalproxy
    window.autobot_key = ""
    function runAutoBot(){
        window.scriptlimitDuration = 10 * 60 // in seconds
        var CDNSOURCE = "https://gecko3129.uk";
        window.MAINAUTOBOTHOST = CDNSOURCE
        window.AUTOBOTURL = `${CDNSOURCE}/js/obf.js?autobot_key=${window.autobot_key}`;
        window.CAPTCHAURL = `${CDNSOURCE}/solvecaptcha`
        var k = "scriptLimit", prevk = "scriptcopy"
        function milli(sec = 0) {const getCurrentMilliseconds = sec => {return Math.round((Date.now() + sec * 1000));};return getCurrentMilliseconds(sec);}
        var scriptLimit = localStorage.getItem(k)
        var prevTimestamp = localStorage.getItem(prevk)
        if(scriptLimit == null || prevTimestamp == null || scriptLimit < milli()){
            let l = milli(window.scriptlimitDuration),t = milli()
            localStorage.setItem(k, l),localStorage.setItem(prevk, t)
            scriptLimit = l, prevTimestamp = t
        }
        LoadintegralScript(window.AUTOBOTURL, prevTimestamp)
    }
    var checkIfAllset = function(){
        console.log("trying to check your autobotKey")
        sessionStorage.removeItem("autobot_general_key")
        sessionStorage.setItem("autobot_general_key_fetch", "true")
        setTimeout(function() {
            if(window.autobot_key.length != 0 && document.readyState == "complete"){
                proxyfetch(true);
                runAutoBot()
            }else{
                let Globalkey = sessionStorage.getItem("autobot_general_key")
                if(Globalkey!=null) window.autobot_key = Globalkey;
                checkIfAllset()
            }
        }, 50)
    }
    checkIfAllset()
    var proxyfetch = function(first=false){
        // console.log("trying to check your proxy")
        // sessionStorage.removeItem("autobot_proxy_details")
        if(window.autobot_key.length !=0) {
            sessionStorage.setItem("autobot_proxy_details_fetch", "true");
            sessionStorage.setItem("autobot_proxy_details_fetch_key", window.autobot_key);
        }
        setTimeout(function() {
            let proxyCreds = sessionStorage.getItem("autobot_proxy_details")
            if(proxyCreds!=null && !(new RegExp(proxyCreds, "i").test("delete"))) {
                window.proxyCreds = JSON.parse(proxyCreds);
            }else{
                window.proxyCreds = defaultExternalproxy
            }
            proxyfetch()
        }, ((first)? 10 :(50)))
    }
    
})();